﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ControlAssuranceAPI.Models
{
    public class XmlDetail
    {
        public int ID { get; set; }
        public string Title { get; set; }
    }
}